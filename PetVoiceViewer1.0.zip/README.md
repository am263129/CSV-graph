# CSV-graph
show video and graph from csv file
